"""Signal Analyzer - single entry point.

Usage:
    python main.py                  = run (everything, with reports)
    python main.py run              sync + parse + live monitoring + reports
    python main.py status           project and database status
    python main.py report           report of what is stored in the database
    python main.py sync             fetch last 500 messages of every channel
    python main.py parse            parse stored messages into signals
    python main.py monitor          history sync + live listening only
    python main.py init-db          create/upgrade database tables
    python main.py verify-db        read-only schema verification
    python main.py export-json      export last 500 messages per channel
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
import time
from pathlib import Path

from config.settings import APP_NAME, APP_VERSION, DATABASE_PATH
from core.exceptions import install_exception_handler
from core.logger import setup_logging

ROOT = Path(__file__).resolve().parent
HISTORY_LIMIT = 500
DEFAULT_PARSE_INTERVAL = 300  # seconds

logger = logging.getLogger("main")

BAR = "=" * 58
LINE = "-" * 58

CATEGORY_NAMES = {
    "TRADE_SIGNAL": "signal",
    "REJECTED_SIGNAL": "signal-e radshode",
    "TRADE_UPDATE": "update",
    "RESULT_REPORT": "gozaresh natije",
    "MARKET_ANALYSIS": "tahlil",
    "MARKET_ALERT": "hoshdar bazar",
    "PROMOTION": "tabligh",
    "NEEDS_REVIEW": "niaz be barresi",
    "OTHER": "sayer",
}


def say(text: str = "") -> None:
    logger.info(text)


# --------------------------------------------------
# Database helpers
# --------------------------------------------------

def _init_db() -> None:
    from database.schema import initialize_schema

    initialize_schema()


def cmd_init_db(args) -> int:
    _init_db()
    say(f"✅ Database amade ast: {DATABASE_PATH}")
    return 0


def cmd_verify_db(args) -> int:
    from database.verify_schema import inspect_database

    errors, notes = inspect_database(DATABASE_PATH)
    for note in notes:
        say(f"ℹ️  {note}")
    for error in errors:
        logger.error(error)
    return 1 if errors else 0


def cmd_status(args) -> int:
    say(f"📁 Poshe proje : {ROOT}")
    say(f"🐍 Python      : {sys.version.split()[0]}")
    say(f"🗄️  Database    : {DATABASE_PATH} "
        f"({'mojood' if DATABASE_PATH.exists() else 'nist'})")
    print_report("vaziat felli")
    return 0


# --------------------------------------------------
# Reports
# --------------------------------------------------

def _short_time(value: str | None) -> str:
    if not value:
        return "-"
    return value.replace("T", " ")[:16] + " UTC"


def print_report(title: str) -> None:
    """Print a readable summary of what is stored in the database."""
    from database.connection import database_connection

    with database_connection() as connection:
        channels = connection.execute(
            """SELECT ch.id, ch.title, COUNT(rm.id) AS messages,
                      COALESCE(SUM(rm.collection_status = 'edited'), 0) AS edited,
                      MAX(rm.message_date) AS last_message
               FROM channels ch
               LEFT JOIN raw_messages rm ON rm.channel_id = ch.id
               GROUP BY ch.id ORDER BY ch.id"""
        ).fetchall()
        signal_rows = connection.execute(
            """SELECT rm.channel_id AS cid, s.validation_status AS status,
                      COUNT(*) AS n
               FROM signals s JOIN raw_messages rm ON rm.id = s.raw_message_id
               GROUP BY rm.channel_id, s.validation_status"""
        ).fetchall()

    by_channel: dict[int, dict[str, int]] = {}
    for row in signal_rows:
        by_channel.setdefault(row["cid"], {})[row["status"]] = row["n"]

    say(BAR)
    say(f"📊 GOZARESH: {title}")
    say(BAR)
    if not channels:
        say("Hanuz hich kanali dar database nist.")

    totals = {"messages": 0, "valid": 0, "invalid": 0, "ambiguous": 0}
    for ch in channels:
        st = by_channel.get(ch["id"], {})
        say(f"📡 {ch['title']}")
        say(f"   💬 payam: {ch['messages']}   ✏️ virayesh vaghei: {ch['edited']}"
            f"   🕒 akharin: {_short_time(ch['last_message'])}")
        say(f"   🎯 signal: ✅ motabar {st.get('valid', 0)}"
            f"  ❌ namotabar {st.get('invalid', 0)}"
            f"  ⚠️ mashkuk {st.get('ambiguous', 0)}")
        totals["messages"] += ch["messages"]
        for key in ("valid", "invalid", "ambiguous"):
            totals[key] += st.get(key, 0)

    say(LINE)
    say(f"📦 JAM KOL: {totals['messages']} payam | ✅ {totals['valid']} motabar"
        f" | ❌ {totals['invalid']} namotabar | ⚠️ {totals['ambiguous']} mashkuk")
    say(BAR)


def _say_parse_summary(summary: dict) -> None:
    counts = summary.get("category_counts", {})
    if not counts:
        say("   (payami baraye parse nabud)")
        return
    parts = [f"{CATEGORY_NAMES.get(k, k)}: {v}" for k, v in
             sorted(counts.items(), key=lambda item: -item[1])]
    say("   🧩 daste bandi payam-ha -> " + " | ".join(parts))


# --------------------------------------------------
# Telegram: history sync
# --------------------------------------------------

async def _sync_all(limit: int) -> list[dict]:
    """Sync every configured channel; one failing channel does not stop the rest."""
    from config.telegram_channels import CHANNELS, get_channel_reference
    from telegram_client.client import create_telegram_client
    from telegram_client.history_sync import sync_channel_history

    client = create_telegram_client()
    results: list[dict] = []
    try:
        await client.start()
        for channel in CHANNELS:
            name = channel.get("name") or str(get_channel_reference(channel))
            say(f"   ⏳ dar hal gereftan: {name} ...")
            try:
                result = await sync_channel_history(
                    client=client, channel_reference=channel, limit=limit,
                )
                results.append({"name": result["channel_title"], "ok": True,
                                "result": result, "error": None})
            except Exception as exc:
                logger.exception("Sync failed for channel %s", name)
                results.append({"name": name, "ok": False, "result": None,
                                "error": f"{type(exc).__name__}: {exc}"})
        return results
    finally:
        if client.is_connected():
            await client.disconnect()


def _say_sync_results(results: list[dict]) -> None:
    for item in results:
        if not item["ok"]:
            say(f"   ❌ {item['name']}: khata -> {item['error']}")
            continue
        r = item["result"]
        say(f"   ✅ {item['name']}: {r['processed']} payam gerefte shod")
        say(f"      ✏️ edit_date dashtan: {r['edit_date_present']} "
            f"(nahan: {r['edit_hidden']} | vaghei: {r['real_edits']})")


def cmd_sync(args) -> int:
    say("📥 Gereftan tarikhche kanal-ha...")
    results = asyncio.run(_sync_all(args.limit))
    _say_sync_results(results)
    print_report("bad az sync")
    return 2 if any(not r["ok"] for r in results) else 0


def cmd_report(args) -> int:
    print_report("vaziat felli")
    return 0


# --------------------------------------------------
# Parsing
# --------------------------------------------------

def cmd_parse(args) -> int:
    import parse_signals

    if args.json is not None:
        source = Path(args.json)
        if not source.exists():
            logger.error("Input path not found: %s", source)
            return 1
        summary = parse_signals.process_json(
            source, Path(args.out), Path(args.csv)
        )
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 0

    summary = parse_signals.process_database(
        limit=args.limit, channel_id=args.channel_id
    )
    _say_parse_summary(summary)
    print_report("bad az parse")
    return 0


# --------------------------------------------------
# Live monitoring and full pipeline
# --------------------------------------------------

def cmd_monitor(args) -> int:
    from telegram_client.monitor import run_monitor

    say("📡 Shoru-e payesh zende...")
    asyncio.run(run_monitor())
    return 0


async def _parse_loop(interval: int) -> None:
    import parse_signals

    while True:
        await asyncio.sleep(interval)
        try:
            summary = await asyncio.to_thread(parse_signals.process_database)
            say("🔄 Parse dore-i anjam shod")
            _say_parse_summary(summary)
            await asyncio.to_thread(print_report, "be-rooz resani")
        except Exception:
            logger.exception("Parse dore-i khata dad; dobare talash mishavad.")


async def _run_pipeline(interval: int, limit: int) -> None:
    import parse_signals
    from telegram_client.monitor import run_monitor

    say(BAR)
    say(f"🚀 {APP_NAME} v{APP_VERSION}")
    say(BAR)

    say("📥 Marhale 1 az 3: gereftan tarikhche kanal-ha")
    results = await _sync_all(limit)
    _say_sync_results(results)

    say("🧩 Marhale 2 az 3: parse payam-ha")
    summary = await asyncio.to_thread(parse_signals.process_database)
    _say_parse_summary(summary)

    await asyncio.to_thread(print_report, "bad az sync avvaliye")
    say("📡 Marhale 3 az 3: payesh zende shoru shod "
        f"(parse har {interval // 60} daghighe). Baraye tavaqof: Ctrl+C")

    tasks = [
        asyncio.create_task(run_monitor(initial_sync=False), name="monitor"),
        asyncio.create_task(_parse_loop(interval), name="parse-loop"),
    ]
    try:
        # The monitor never returns normally; if it fails, stop everything.
        await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        for task in tasks:
            if task.done() and not task.cancelled() and task.exception():
                raise task.exception()
    finally:
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


def cmd_run(args) -> int:
    asyncio.run(_run_pipeline(args.parse_interval, args.limit))
    return 0


# --------------------------------------------------
# JSON export of messages
# --------------------------------------------------

def cmd_export_json(args) -> int:
    import extract_telegram_500

    return asyncio.run(extract_telegram_500.main())


# --------------------------------------------------
# CLI
# --------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=f"{APP_NAME} - Telegram signal analysis",
    )
    sub = parser.add_subparsers(dest="command")

    sub.add_parser("status", help="show project and database status")
    sub.add_parser("report", help="report of stored data")
    sub.add_parser("init-db", help="create or upgrade database tables")
    sub.add_parser("verify-db", help="read-only database schema check")

    p = sub.add_parser("sync", help="fetch recent history of all channels")
    p.add_argument("--limit", type=int, default=HISTORY_LIMIT,
                   help=f"messages per channel (default {HISTORY_LIMIT})")

    p = sub.add_parser("parse", help="parse stored messages into signals")
    p.add_argument("--channel-id", type=int, help="only this local channel ID")
    p.add_argument("--limit", type=int, help="max messages to process")
    p.add_argument("--json", metavar="PATH", nargs="?",
                   const="data/json exports",
                   help="parse legacy JSON exports instead of the database")
    p.add_argument("--out", default="data/exports/parsed_signals.json")
    p.add_argument("--csv", default="data/exports/parsed_signals.csv")

    sub.add_parser("monitor", help="history sync + live messages and edits")

    p = sub.add_parser("run", help="full pipeline: sync, parse, live monitor")
    p.add_argument("--parse-interval", type=int, default=DEFAULT_PARSE_INTERVAL,
                   help="seconds between parse runs (default 300)")
    p.add_argument("--limit", type=int, default=HISTORY_LIMIT,
                   help=f"messages per channel at start (default {HISTORY_LIMIT})")

    sub.add_parser("export-json", help="export last 500 messages per channel")
    return parser


COMMANDS = {
    "status": cmd_status,
    "report": cmd_report,
    "init-db": cmd_init_db,
    "verify-db": cmd_verify_db,
    "sync": cmd_sync,
    "parse": cmd_parse,
    "monitor": cmd_monitor,
    "run": cmd_run,
    "export-json": cmd_export_json,
}


def main() -> int:
    # Make emoji safe on any console.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass

    setup_logging()
    install_exception_handler()

    parser = build_parser()
    args = parser.parse_args()
    if args.command is None:
        # Plain "python main.py" (e.g. the IDE Run button) runs everything.
        args = parser.parse_args(["run"])
    command = args.command

    started_at = time.perf_counter()

    try:
        # The database is created/upgraded automatically on every start
        # (verify-db is read-only by design and skips this).
        if command != "verify-db":
            _init_db()
        exit_code = COMMANDS[command](args)
    except KeyboardInterrupt:
        say("⏹️  Motevaqef shod tavasot-e shoma.")
        exit_code = 130
    except Exception:
        logger.exception("Dastur '%s' ba khata ruberu shod", command)
        exit_code = 1

    if command != "run" or exit_code != 0:
        say(f"🏁 Payan: {command} | code={exit_code} | "
            f"zaman={time.perf_counter() - started_at:.1f}s")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
